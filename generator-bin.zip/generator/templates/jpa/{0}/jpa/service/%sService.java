package ${servicePackage};

import ${entityPackage}.${entityName};

#parse('/templates/commons/comment.vm')
public interface ${className} {
	
}
